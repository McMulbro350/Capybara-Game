// ============================================================================
// CAPYBARA BEAN BOUNCE
//
// This file is organized into these sections:
//   1. LEVEL_CONFIGS & GAME_CONFIG - all tunable numbers live here
//   2. Asset loading                - loads the canvas-drawn images
//   3. Progress (level unlocks)      - saved to localStorage
//   4. Setup & state                 - canvas, lanes, game state variables
//   5. Player (capybara)             - position, movement, jump, drawing
//   6. Jelly beans                    - fair "always something falling" spawner
//   7. Collision detection
//   8. Score & high score
//   9. Background drawing (sky gradient, drifting clouds, ground art)
//  10. Game loop
//  11. Input handling (buttons, keyboard, touch)
//  12. Title screen intro animation
//  13. Level select screen
//  14. Level flow (start / win / lose) + screen transitions
// ============================================================================


// ----------------------------------------------------------------------------
// 1. LEVEL_CONFIGS & GAME_CONFIG
//
//    LEVEL_CONFIGS holds only the numbers that change between levels
//    (speed, spawn rate, how many beans you need to dodge to win, and which
//    background art to use) — the rest of the game already reads from
//    whichever level is currently active.
//
//    GAME_CONFIG holds everything else (sizes, movement feel, hitboxes)
//    that stays the same across every level.
// ----------------------------------------------------------------------------
const LEVEL_CONFIGS = {
    1: {
        label: 'Level 1 — Easy',
        jellyBeanSpeed: 195,     // pixels per second they fall
        spawnIntervalMin: 500,   // ms between spawns (min) — keeps the sky lively
        spawnIntervalMax: 900,   // ms (max)
        maxActiveBeans: 2,       // never more than this many falling at once
        winScore: 10             // beans you must dodge to clear the level
    },
    2: {
        label: 'Level 2 — Medium',
        jellyBeanSpeed: 240,     // a bit faster than Level 1
        spawnIntervalMin: 380,   // and spawns noticeably more often
        spawnIntervalMax: 650,
        maxActiveBeans: 2,       // kept the same as Level 1 so the flow stays even —
                                  // difficulty comes from speed/frequency, not clumping
        winScore: 20
    },
    3: {
        label: 'Level 3 — Hard',
        jellyBeanSpeed: 280,     // faster again than Level 2
        spawnIntervalMin: 280,   // and spawns even more often
        spawnIntervalMax: 480,
        maxActiveBeans: 2,
        winScore: 30
    }
};
const TOTAL_LEVELS = 3; // level-select shows this many badges

// Filled in by build.py with real base64 data URIs for every canvas-drawn
// image (capybara, jelly beans, per-level ground/sky, clouds). Kept as a
// separate object (rather than editing this file by hand) so script.js
// stays readable — see build.py in the project source.
const ASSET_DATA_URIS = {
    /* ASSET_DATA_URIS_PLACEHOLDER */
};

const GAME_CONFIG = {
    laneCount: 3,

    // Jelly beans (visual size / hitbox — falling speed lives in LEVEL_CONFIGS)
    jellyBeanDisplayWidth: 40,
    jellyBeanHitboxSafeFraction: 0.72, // collision radius as a fraction of the bean's own half-size

    // Player (capybara)
    playerMoveSpeed: 12,          // how quickly the capybara slides to a new lane (higher = snappier)
    capybaraDisplayWidth: 96,
    capybaraHitboxSafeFraction: 0.55, // collision radius as a fraction of the capybara's own half-size
    jumpAnimationDurationMs: 380,     // how long the "jump" sprite shows after a lane change
    jumpBounceHeight: 12,             // purely visual hop height in pixels (does not affect collision)

    // Clouds — each drifts slowly and loops around when it exits the screen
    clouds: [
        { file: 'cloud_1.png', width: 92, yFraction: 0.16, xFraction: 0.15, speed: 9 },
        { file: 'cloud_2.png', width: 88, yFraction: 0.34, xFraction: 0.80, speed: 13 },
        { file: 'cloud_3.png', width: 60, yFraction: 0.48, xFraction: 0.05, speed: 6 },
        { file: 'cloud_4.png', width: 58, yFraction: 0.58, xFraction: 0.90, speed: 11 }
    ]
};


// ----------------------------------------------------------------------------
// 2. Asset loading
//    Every image (including the title/button/badge art used in plain HTML
//    <img> tags) is embedded directly as a base64 data URI — see the bottom
//    of this file / index.html. That means the whole game is self-contained
//    in these two files with no separate image files or CSS file to fetch,
//    so it can't break due to relative-path or local-file security quirks
//    in whatever browser or environment opens it.
// ----------------------------------------------------------------------------
function loadImage(dataUri) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = dataUri;
    });
}

const assets = {}; // filled in once loading finishes

async function loadAllAssets() {
    const beanKeys = [1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => `bean_${n}.png`);
    const cloudKeys = GAME_CONFIG.clouds.map(c => c.file);
    const groundKeys = [1, 2, 3].map(n => `ground_layer_${n}.png`);
    const skyKeys = [1, 2, 3].map(n => `sky_gradient_${n}.png`);

    const [capybaraStill, capybaraJump, ground1, ground2, ground3, sky1, sky2, sky3, ...rest] =
        await Promise.all([
            loadImage(ASSET_DATA_URIS['capybara_still.png']),
            loadImage(ASSET_DATA_URIS['capybara_jump.png']),
            ...groundKeys.map(k => loadImage(ASSET_DATA_URIS[k])),
            ...skyKeys.map(k => loadImage(ASSET_DATA_URIS[k])),
            ...beanKeys.map(k => loadImage(ASSET_DATA_URIS[k])),
            ...cloudKeys.map(k => loadImage(ASSET_DATA_URIS[k]))
        ]);

    assets.capybaraStill = capybaraStill;
    assets.capybaraJump = capybaraJump;
    assets.grounds = { 1: ground1, 2: ground2, 3: ground3 };
    assets.skyGradients = { 1: sky1, 2: sky2, 3: sky3 };
    assets.beans = rest.slice(0, beanKeys.length);
    assets.clouds = rest.slice(beanKeys.length);
}


// ----------------------------------------------------------------------------
// 3. Progress (which levels are unlocked) — saved to localStorage
// ----------------------------------------------------------------------------
const PROGRESS_KEY = 'capybaraBeanBounce_progress';

function loadProgress() {
    try {
        const saved = JSON.parse(localStorage.getItem(PROGRESS_KEY));
        if (saved && typeof saved.unlockedLevel === 'number') return saved;
    } catch (e) {
        // ignore malformed/missing data and fall back to defaults below
    }
    return { unlockedLevel: 1 };
}

function saveProgress() {
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress));
}

let progress = loadProgress();


// ----------------------------------------------------------------------------
// 4. Setup & state
// ----------------------------------------------------------------------------
const canvas = document.getElementById('game-canvas');
const ctx = canvas.getContext('2d');

const CANVAS_WIDTH = canvas.width;   // 360 — fixed internal resolution.
const CANVAS_HEIGHT = canvas.height; // 720 — CSS scales this to fit the screen.

// Work out the x position (center) of each of the 3 lanes.
const LANE_WIDTH = CANVAS_WIDTH / GAME_CONFIG.laneCount;
const LANE_CENTERS = [];
for (let i = 0; i < GAME_CONFIG.laneCount; i++) {
    LANE_CENTERS.push(LANE_WIDTH * i + LANE_WIDTH / 2);
}

// Game state: 'loading' | 'title' | 'levelSelect' | 'playing' | 'levelComplete' | 'gameover'
let gameState = 'loading';

let currentLevel = 1;
let currentLevelConfig = LEVEL_CONFIGS[1];

let activeBeans = [];      // jelly beans currently falling
let spawnTimer = 0;        // counts down (ms) until the next bean may spawn
let beansSpawnedThisLevel = 0; // how many beans have been sent out so far this level
let spawnBudget = 0;       // stop spawning once beansSpawnedThisLevel reaches this
                            // (starts at winScore, +1 for every hit — see handleHit)
let score = 0;

const STARTING_LIVES = 3;
let lives = STARTING_LIVES;              // reset to 3 at the start of every level
let invincibleUntil = 0;                 // timestamp (ms) until hit-detection is paused after taking a hit
const INVINCIBILITY_MS = 900;            // brief grace period after getting hit

let lastFrameTime = null;

// The capybara's current lane (0 = left, 1 = middle, 2 = right)
let playerLane = 1;
// Its animated x position (slides smoothly toward the target lane's x)
let playerX = LANE_CENTERS[playerLane];

// Ground/sky layout — computed once assets are loaded (depends on the
// Ground/sky layout — recomputed whenever the active level changes (each
// level's background art can have a slightly different aspect ratio).
let groundDisplayHeight = 0;
let groundTopY = 0;
let playerY = 0;

// The capybara's collision circle — computed once from the STILL sprite so
// it stays perfectly consistent even while the jump sprite (a slightly
// different size) is briefly showing. See computeLayout() for the math.
let capybaraCollisionCenterY = 0;
let capybaraCollisionRadius = 0;


function computeLayout() {
    const groundImg = assets.grounds[currentLevel];
    groundDisplayHeight = groundImg.naturalHeight * (CANVAS_WIDTH / groundImg.naturalWidth);
    groundTopY = CANVAS_HEIGHT - groundDisplayHeight;
    // Stand the capybara on the flat ground, above where the on-screen buttons sit.
    playerY = groundTopY + groundDisplayHeight * 0.56;

    // The capybara sprite is drawn with its TOP edge at (playerY - refH*0.72)
    // (see drawCapybara), so its true visual center sits a bit above playerY.
    // Work that out here, then size the collision circle to comfortably fit

    // inside the sprite's own width/height — never larger than either —
    // so the hitbox can never poke out past the art in any direction.
    const refH = GAME_CONFIG.capybaraDisplayWidth *
        (assets.capybaraStill.naturalHeight / assets.capybaraStill.naturalWidth);
    capybaraCollisionCenterY = playerY - refH * 0.22;
    capybaraCollisionRadius =
        (Math.min(GAME_CONFIG.capybaraDisplayWidth, refH) / 2) * GAME_CONFIG.capybaraHitboxSafeFraction;
}


// ----------------------------------------------------------------------------
// 5. Player (capybara) — movement, jump animation, drawing
// ----------------------------------------------------------------------------
let playerJumpUntil = 0; // timestamp (ms) until which the "jump" sprite is shown
let facingDirection = 'right'; // 'right' or 'left' — flips the capybara sprite to match

function movePlayerLeft() {
    if (gameState !== 'playing') return;
    if (playerLane > 0) {
        playerLane -= 1;
        facingDirection = 'left';
        triggerJumpAnimation();
    }
}

function movePlayerRight() {
    if (gameState !== 'playing') return;
    if (playerLane < GAME_CONFIG.laneCount - 1) {
        playerLane += 1;
        facingDirection = 'right';
        triggerJumpAnimation();
    }
}

function triggerJumpAnimation() {
    playerJumpUntil = performance.now() + GAME_CONFIG.jumpAnimationDurationMs;
}

function updatePlayer(dt) {
    const targetX = LANE_CENTERS[playerLane];
    // Smoothly slide toward the target lane instead of snapping instantly.
    const closeAmount = Math.min(1, GAME_CONFIG.playerMoveSpeed * dt);
    playerX += (targetX - playerX) * closeAmount;
}

function drawCapybara(now) {
    const isJumping = now < playerJumpUntil;
    const img = isJumping ? assets.capybaraJump : assets.capybaraStill;

    const w = GAME_CONFIG.capybaraDisplayWidth;
    const h = w * (img.naturalHeight / img.naturalWidth);

    // Small cosmetic hop while the jump sprite is showing (visual only —
    // collision detection always uses the capybara's resting position).
    let bounce = 0;
    if (isJumping) {
        const remaining = playerJumpUntil - now;
        const progress = 1 - remaining / GAME_CONFIG.jumpAnimationDurationMs; // 0 -> 1
        bounce = Math.sin(progress * Math.PI) * GAME_CONFIG.jumpBounceHeight;
    }

    const drawY = playerY - h * 0.72 - bounce;

    // Quick blinking flash during the post-hit invincibility window, so a
    // lost heart always comes with a clear visual cue.
    const flashing = now < invincibleUntil;
    if (flashing) {
        ctx.save();
        ctx.globalAlpha = 0.4 + 0.6 * Math.abs(Math.sin(now / 60));
    }

    // The source art faces right by default, so mirror it horizontally
    // whenever the capybara is facing left.
    if (facingDirection === 'left') {
        ctx.save();
        ctx.translate(playerX, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(img, -w / 2, drawY, w, h);
        ctx.restore();
    } else {
        ctx.drawImage(img, playerX - w / 2, drawY, w, h);
    }

    if (flashing) ctx.restore();
}


// ----------------------------------------------------------------------------
// 6. Jelly beans — a fair, "always something falling" spawner
//
//    FAIRNESS RULE: at any moment, exactly one lane is designated the
//    "rest lane" and never receives a new spawn — so it's always a safe
//    lane to dodge into, by construction. The other two lanes take turns
//    (see ALTERNATION RULE below). The rest lane itself rotates every few
//    spawns, so over a whole level every lane gets used evenly rather than
//    the game getting stuck cycling between the same two lanes forever.
//
//    ALTERNATION RULE: a new bean also never spawns in the SAME lane as the
//    immediately previous spawn — lastSpawnedLane is excluded from the
//    candidates (unless that's the only option available), so beans never
//    repeat a lane back-to-back.
//
//    Spawning stops once beansSpawnedThisLevel reaches spawnBudget (which
//    starts equal to the level's winScore, and increases by 1 every time
//    you get hit — see handleHit(). Without this, getting hit would burn
//    through a spawn without earning a point for it, making it impossible
//    to ever reach winScore successful dodges — a permanent soft-lock.
// ----------------------------------------------------------------------------
let lastSpawnedLane = null;
let restLane = 0;             // the lane currently excluded from spawning
let spawnsSinceRotation = 0;
const ROTATE_REST_LANE_AFTER = 3; // how many spawns before the rest lane moves on

function spawnBean(lane) {
    const img = assets.beans[Math.floor(Math.random() * assets.beans.length)];
    const w = GAME_CONFIG.jellyBeanDisplayWidth;
    const h = w * (img.naturalHeight / img.naturalWidth);
    activeBeans.push({
        lane: lane,
        x: LANE_CENTERS[lane],
        y: -h,
        speed: currentLevelConfig.jellyBeanSpeed,
        img: img,
        // Sized to this specific bean's own art, so the hitbox never
        // reaches past its actual width or height in any direction.
        radius: (Math.min(w, h) / 2) * GAME_CONFIG.jellyBeanHitboxSafeFraction,
        scored: false // becomes true the moment it passes the capybara (see updateBeans)
    });
    lastSpawnedLane = lane;

    beansSpawnedThisLevel += 1;
    spawnsSinceRotation += 1;
    if (spawnsSinceRotation >= ROTATE_REST_LANE_AFTER) {
        spawnsSinceRotation = 0;
        restLane = (restLane + 1) % GAME_CONFIG.laneCount;
    }
}

function updateSpawning(dtMs) {
    spawnTimer -= dtMs;

    const screenIsEmpty = activeBeans.length === 0; // never leave the sky completely clear
    const stillMoreToSend = beansSpawnedThisLevel < spawnBudget;

    if ((spawnTimer <= 0 || screenIsEmpty) &&
        activeBeans.length < currentLevelConfig.maxActiveBeans &&
        stillMoreToSend) {
        let candidateLanes = [];
        for (let i = 0; i < GAME_CONFIG.laneCount; i++) {
            if (i !== restLane) candidateLanes.push(i);
        }
        // Exclude a same-lane repeat, but only if that still leaves a choice —
        // never end up with zero candidates.
        if (candidateLanes.length > 1 && lastSpawnedLane !== null) {
            candidateLanes = candidateLanes.filter(lane => lane !== lastSpawnedLane);
        }
        const lane = candidateLanes[Math.floor(Math.random() * candidateLanes.length)];
        spawnBean(lane);

        spawnTimer = currentLevelConfig.spawnIntervalMin +
            Math.random() * (currentLevelConfig.spawnIntervalMax - currentLevelConfig.spawnIntervalMin);
    }
}

function updateBeans(dt) {
    for (const bean of activeBeans) {
        bean.y += bean.speed * dt;
    }

    // Check for a hit BEFORE scoring, and remove the offending bean right
    // away — that way a bean that hits you can never also be counted as
    // "passed" in the scoring pass below.
    if (!isInvincible()) {
        const hitIndex = activeBeans.findIndex(bean => {
            const dx = bean.x - playerX;
            const dy = bean.y - capybaraCollisionCenterY;
            return Math.sqrt(dx * dx + dy * dy) < capybaraCollisionRadius + bean.radius;
        });
        if (hitIndex !== -1) {
            activeBeans.splice(hitIndex, 1);
            handleHit();
        }
    }

    for (const bean of activeBeans) {
        // The score counts beans that get past you, not survival time —
        // award the point the instant a bean's center passes your row.
        if (!bean.scored && bean.y > capybaraCollisionCenterY) {
            bean.scored = true;
            score += 1;
        }
    }
    // Remove beans that have fallen off the bottom of the screen.
    activeBeans = activeBeans.filter(bean => bean.y - GAME_CONFIG.jellyBeanDisplayWidth < CANVAS_HEIGHT);
}

function drawJellyBean(bean) {
    const w = GAME_CONFIG.jellyBeanDisplayWidth;
    const h = w * (bean.img.naturalHeight / bean.img.naturalWidth);
    ctx.drawImage(bean.img, bean.x - w / 2, bean.y - h / 2, w, h);
}


// ----------------------------------------------------------------------------
// 7. Hits & lives
//    Getting hit costs one heart and starts a brief invincibility window
//    (so the same near-miss can't immediately cost a second heart), rather
//    than ending the level outright. The level only ends when lives hit 0.
// ----------------------------------------------------------------------------
function isInvincible() {
    return performance.now() < invincibleUntil;
}

function handleHit() {
    lives -= 1;
    invincibleUntil = performance.now() + INVINCIBILITY_MS;
    updateHeartsDisplay();

    // A hit bean never earns a point, so without this, taking a hit would
    // permanently reduce how many chances you have left to reach winScore
    // successful dodges. Adding one more bean to spawn per hit keeps the
    // level completable no matter how many times you get hit (as long as
    // you still have lives left).
    spawnBudget += 1;

    if (lives <= 0) {
        triggerGameOver();
    }
}


// ----------------------------------------------------------------------------
// 8. Score & lives display
// ----------------------------------------------------------------------------
function updateHud() {
    document.getElementById('score-display').textContent = 'Score: ' + score;
}

function updateHeartsDisplay() {
    document.querySelectorAll('.heart-icon').forEach((el, i) => {
        el.classList.toggle('lost', i >= lives);
    });
}



// ----------------------------------------------------------------------------
// 9. Background drawing (sky gradient, drifting clouds, ground art)
// ----------------------------------------------------------------------------
function drawSky() {
    // The sky gradient image is just a thin vertical strip of the exact
    // colors from the original artwork — stretching it to fill the sky
    // area keeps the gradient pixel-accurate without hardcoding colors.
    ctx.drawImage(assets.skyGradients[currentLevel], 0, 0, CANVAS_WIDTH, groundTopY);
}

function drawClouds(timeMs) {
    const t = timeMs / 1000; // seconds
    GAME_CONFIG.clouds.forEach((cfg, i) => {
        const img = assets.clouds[i];
        const w = cfg.width;
        const h = w * (img.naturalHeight / img.naturalWidth);
        const totalRange = CANVAS_WIDTH + w;
        const startOffset = cfg.xFraction * totalRange;
        const x = ((startOffset + t * cfg.speed) % totalRange) - w;
        const y = cfg.yFraction * groundTopY;
        ctx.drawImage(img, x, y, w, h);
    });
}

function drawGround() {
    ctx.drawImage(assets.grounds[currentLevel], 0, groundTopY, CANVAS_WIDTH, groundDisplayHeight);
}

function drawBackground(timeMs) {
    drawSky();
    drawClouds(timeMs);
    drawGround();
}


// ----------------------------------------------------------------------------
// 10. Game loop
// ----------------------------------------------------------------------------
function gameLoop(timestamp) {
    if (lastFrameTime === null) lastFrameTime = timestamp;
    const dtMs = Math.min(50, timestamp - lastFrameTime); // clamp to avoid huge jumps (e.g. tab switch)
    const dt = dtMs / 1000;
    lastFrameTime = timestamp;

    if (gameState === 'playing') {
        updateSpawning(dtMs);
        updateBeans(dt); // also checks for hits and handles them internally now
        updatePlayer(dt);
        updateHud();

        // Re-check gameState: a hit this frame may have already ended the
        // game (lives hit 0), in which case skip the win check entirely.
        if (gameState === 'playing' && score >= currentLevelConfig.winScore) {
            completeLevel();
        }
    }

    // The sky/clouds/ground keep drifting behind every screen, including
    // the title and level-select overlays, for a lively, continuous feel.
    drawBackground(timestamp);

    // Only draw the gameplay capybara/beans while actually playing (or on
    // the game-over screen, so the moment of collision is still visible) —
    // the title screen has its own separate capybara graphic.
    if (gameState === 'playing' || gameState === 'gameover') {
        for (const bean of activeBeans) drawJellyBean(bean);
        drawCapybara(timestamp);
    }

    requestAnimationFrame(gameLoop);
}


// ----------------------------------------------------------------------------
// 11. Input handling — keyboard, on-screen buttons, and touch
// ----------------------------------------------------------------------------
document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowLeft') movePlayerLeft();
    if (e.key === 'ArrowRight') movePlayerRight();
});

const btnLeft = document.getElementById('btn-left');
const btnRight = document.getElementById('btn-right');

// pointerdown covers mouse clicks AND touch taps with no extra delay.
btnLeft.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    movePlayerLeft();
});
btnRight.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    movePlayerRight();
});


// ----------------------------------------------------------------------------
// 12. Title screen intro animation
//     The logo, capybara, and Play button all jump toward the viewer at the
//     same time. The logo and capybara then settle into a gentle infinite
//     wobble once their landing animation actually finishes (via
//     'animationend'), so it stays in sync even if timings change.
// ----------------------------------------------------------------------------
function runTitleIntro() {
    const scene = document.getElementById('title-scene');
    const logo = document.getElementById('title-logo');
    const capy = document.getElementById('title-capybara');
    const playBtn = document.getElementById('btn-play');

    scene.classList.remove('hidden');

    [logo, capy, playBtn].forEach(el => {
        el.classList.remove('hidden');
        el.classList.add('jump-in');
    });

    // Swap (not stack) the animation classes: .jump-in also sets a static
    // opacity:0 for its "not yet landed" resting state, so leaving it on
    // alongside .wobble would make the element pop back to invisible the
    // moment the wobble animation takes over.
    logo.addEventListener('animationend', () => {
        logo.classList.remove('jump-in');
        logo.classList.add('wobble');
    }, { once: true });

    capy.addEventListener('animationend', () => {
        capy.classList.remove('jump-in');
        capy.classList.add('wobble');
    }, { once: true });

    // The Play button just holds its landed pose (animation-fill-mode:
    // forwards already keeps it there) — no continuous wobble needed.
}


// ----------------------------------------------------------------------------
// 13. Level select screen
// ----------------------------------------------------------------------------
const levelSelectScreen = document.getElementById('level-select-screen');

function renderLevelSelect() {
    document.querySelectorAll('.level-btn').forEach(btn => {
        const level = parseInt(btn.dataset.level, 10);
        btn.classList.toggle('locked', level > progress.unlockedLevel);
    });
}

function showLevelSelectToast(message) {
    const toast = document.getElementById('level-select-toast');
    toast.textContent = message;
    toast.classList.add('toast-visible');
    clearTimeout(showLevelSelectToast.timer);
    showLevelSelectToast.timer = setTimeout(() => toast.classList.remove('toast-visible'), 1500);
}

document.querySelectorAll('.level-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const level = parseInt(btn.dataset.level, 10);
        const unlocked = level <= progress.unlockedLevel;

        if (!unlocked) {
            btn.classList.remove('shake');
            requestAnimationFrame(() => btn.classList.add('shake'));
            return;
        }
        if (!LEVEL_CONFIGS[level]) {
            showLevelSelectToast('Coming soon!'); // badge is unlocked, but this level isn't built yet
            return;
        }

        levelSelectScreen.classList.add('hidden');
        startGame(level);
    });
});

// Hold-to-reset progress button — has to be held down continuously for the
// full RESET_HOLD_MS, filling a bar as visual feedback. Releasing early
// cancels it with no effect.
const RESET_HOLD_MS = 5000;
const resetBtn = document.getElementById('btn-reset-progress');
const resetBtnFill = resetBtn.querySelector('.reset-btn-fill');
let resetHoldTimer = null;

function startResetHold() {
    if (resetHoldTimer !== null) return; // already holding
    resetBtnFill.style.transition = `width ${RESET_HOLD_MS}ms linear`;
    resetBtnFill.style.width = '100%';
    resetHoldTimer = setTimeout(() => {
        progress.unlockedLevel = 1;
        saveProgress();
        renderLevelSelect(); // grays levels 2 & 3 back out immediately
        showLevelSelectToast('Progress reset!');
        cancelResetHold();
    }, RESET_HOLD_MS);
}

function cancelResetHold() {
    clearTimeout(resetHoldTimer);
    resetHoldTimer = null;
    resetBtnFill.style.transition = 'width 0.2s ease';
    resetBtnFill.style.width = '0%';
}

resetBtn.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    startResetHold();
});
['pointerup', 'pointerleave', 'pointercancel'].forEach(evt =>
    resetBtn.addEventListener(evt, cancelResetHold)
);


// ----------------------------------------------------------------------------
// 14. Level flow (start / win / lose) + screen transitions
// ----------------------------------------------------------------------------
const titleScreen = document.getElementById('title-screen');
const gameOverScreen = document.getElementById('game-over-screen');
const levelCompleteScreen = document.getElementById('level-complete-screen');
const winScreen = document.getElementById('win-screen');
const hudEl = document.getElementById('hud');
const controlsEl = document.getElementById('controls');
const screenBackdrop = document.getElementById('screen-backdrop');

// Crossfades hideEl and showEl at the same time (rather than fully fading
// one out before fading the other in), so the transition reads as a clean
// blend directly from one screen's color to the other's.
function fadeSwap(hideEl, showEl, duration = 600) {
    showEl.classList.remove('hidden');
    showEl.style.opacity = '0';
    showEl.style.transition = `opacity ${duration}ms ease`;
    hideEl.style.transition = `opacity ${duration}ms ease`;

    requestAnimationFrame(() => {
        hideEl.style.opacity = '0';
        showEl.style.opacity = '1';
    });

    setTimeout(() => {
        hideEl.classList.add('hidden');
        hideEl.style.opacity = '';
        hideEl.style.transition = '';
        showEl.style.opacity = '';
        showEl.style.transition = '';
    }, duration);
}

document.getElementById('btn-play').addEventListener('click', () => {
    renderLevelSelect();
    fadeSwap(titleScreen, levelSelectScreen, 600);
    gameState = 'levelSelect';
});

function startGame(level) {
    currentLevel = level;
    currentLevelConfig = LEVEL_CONFIGS[level];
    computeLayout(); // each level's background art has its own aspect ratio

    activeBeans = [];
    spawnTimer = 0; // spawn the first bean right away
    beansSpawnedThisLevel = 0;
    spawnBudget = currentLevelConfig.winScore; // grows by 1 per hit (see handleHit)
    lastSpawnedLane = null;
    restLane = 0;
    spawnsSinceRotation = 0;
    score = 0;
    playerLane = 1;
    playerX = LANE_CENTERS[playerLane];
    playerJumpUntil = 0;
    invincibleUntil = 0;
    facingDirection = 'right';
    lives = STARTING_LIVES; // every level starts with a fresh set of 3 lives

    updateHud();
    updateHeartsDisplay();
    gameOverScreen.classList.add('hidden');
    levelCompleteScreen.classList.add('hidden');
    winScreen.classList.add('hidden');
    hudEl.classList.remove('hidden');
    controlsEl.classList.remove('hidden');
    screenBackdrop.classList.add('hidden'); // reveal the live canvas
    gameState = 'playing';
}

function triggerGameOver() {
    gameState = 'gameover';

    hudEl.classList.add('hidden');
    controlsEl.classList.add('hidden');

    document.getElementById('final-score').textContent = 'Score: ' + score;
    gameOverScreen.classList.remove('hidden');
}

function completeLevel() {
    hudEl.classList.add('hidden');
    controlsEl.classList.add('hidden');

    // Unlock the next level (if this was the newest one beaten).
    if (currentLevel === progress.unlockedLevel && progress.unlockedLevel < TOTAL_LEVELS) {
        progress.unlockedLevel = currentLevel + 1;
        saveProgress();
    }

    if (currentLevel === TOTAL_LEVELS) {
        // Beat the last level — show the win screen instead of the brief
        // "Level Complete!" flash back to Select.
        gameState = 'win';
        winScreen.classList.remove('hidden');
        return;
    }

    gameState = 'levelComplete';
    levelCompleteScreen.classList.remove('hidden');

    setTimeout(() => {
        levelCompleteScreen.classList.add('hidden');
        screenBackdrop.classList.remove('hidden'); // cover the canvas again before Select shows
        renderLevelSelect();
        levelSelectScreen.classList.remove('hidden');
        gameState = 'levelSelect';
    }, 1600);
}

document.getElementById('btn-play-again').addEventListener('click', () => startGame(currentLevel));

document.getElementById('btn-to-level-select').addEventListener('click', () => {
    gameOverScreen.classList.add('hidden');
    screenBackdrop.classList.remove('hidden'); // cover the canvas again before Select shows
    renderLevelSelect();
    levelSelectScreen.classList.remove('hidden');
    gameState = 'levelSelect';
});

document.getElementById('btn-win-play-again').addEventListener('click', () => startGame(TOTAL_LEVELS));

document.getElementById('btn-win-level-select').addEventListener('click', () => {
    winScreen.classList.add('hidden');
    screenBackdrop.classList.remove('hidden'); // cover the canvas again before Select shows
    renderLevelSelect();
    levelSelectScreen.classList.remove('hidden');
    gameState = 'levelSelect';
});


// ----------------------------------------------------------------------------
// Boot up: load assets, compute layout, then run the title screen intro
// and kick off the render loop (which draws the drifting background right
// away, even before Play is pressed).
// ----------------------------------------------------------------------------
loadAllAssets().then(() => {
    computeLayout();
    document.getElementById('loading-text').classList.add('hidden');
    gameState = 'title';
    runTitleIntro();
    requestAnimationFrame(gameLoop);
}).catch(err => {
    console.error('Failed to load game assets:', err);
    document.getElementById('loading-text').textContent = 'Could not load game assets.';
});
