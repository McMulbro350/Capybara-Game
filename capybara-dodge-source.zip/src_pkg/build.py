"""
Build a single, fully self-contained index.html from the editable source
files (index.html template, style.css, script.js, assets/*.png).

Why: relative file paths (assets/xxx.png, style.css) can fail to resolve in
some browsers/preview environments when a game is opened locally. Embedding
everything as inline <style>, inline <script>, and base64 data URIs removes
every external file request, so the game can't break for that reason.

Run this after editing index.html / style.css / script.js / assets/*.png.
"""
import base64
import os

SRC_DIR = os.path.dirname(os.path.abspath(__file__))

def read(name):
    with open(os.path.join(SRC_DIR, name), 'r', encoding='utf-8') as f:
        return f.read()

def b64_data_uri(path):
    with open(path, 'rb') as f:
        data = f.read()
    return 'data:image/png;base64,' + base64.b64encode(data).decode('ascii')

# ---- 1. Canvas-drawn images -> ASSET_DATA_URIS object injected into JS ----
CANVAS_ASSET_FILES = (
    ['capybara_still.png', 'capybara_jump.png'] +
    [f'ground_layer_{n}.png' for n in range(1, 4)] +
    [f'sky_gradient_{n}.png' for n in range(1, 4)] +
    [f'bean_{n}.png' for n in range(1, 10)] +
    [f'cloud_{n}.png' for n in range(1, 5)]
)

entries = []
for fname in CANVAS_ASSET_FILES:
    uri = b64_data_uri(os.path.join(SRC_DIR, 'assets', fname))
    entries.append(f"    '{fname}': '{uri}',")
asset_data_block = '\n'.join(entries)

script_js = read('script.js')
assert '/* ASSET_DATA_URIS_PLACEHOLDER */' in script_js, 'placeholder missing from script.js'
script_js = script_js.replace('/* ASSET_DATA_URIS_PLACEHOLDER */', asset_data_block)

# ---- 2. CSS, inlined verbatim ----
style_css = read('style.css')

# ---- 3. HTML <img> tags -> base64 data URIs ----
DOM_IMAGE_FILES = [
    'title_logo.png', 'btn_play.png', 'arrow_left.png', 'arrow_right.png',
    'level_1_badge.png', 'level_2_badge.png', 'level_3_badge.png',
    'capybara_still.png'
]

html = read('index.html')

html = html.replace(
    '<link rel="stylesheet" href="style.css" />',
    f'<style>\n{style_css}\n</style>'
)
html = html.replace(
    '<script src="script.js"></script>',
    f'<script>\n{script_js}\n</script>'
)

for fname in DOM_IMAGE_FILES:
    uri = b64_data_uri(os.path.join(SRC_DIR, 'assets', fname))
    old = f'src="assets/{fname}"'
    new = f'src="{uri}"'
    count = html.count(old)
    assert count > 0, f'{old!r} not found in index.html'
    html = html.replace(old, new)

out_path = os.path.join(SRC_DIR, 'dist_index.html')
with open(out_path, 'w', encoding='utf-8') as f:
    f.write(html)

print('wrote', out_path, '-', os.path.getsize(out_path) / 1024 / 1024, 'MB')
